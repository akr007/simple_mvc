<?php
/**
 * The controller of the mailform
 * Class ContactController
 */
class ContactController extends Controller
{
	/**
	 * Handles the contact form
	 * @param array $params Unused here
	 */
	public function process($params)
	{
		// Sets HTML meta-data
		$this->head = array(
			'title' => 'Contact form',
			'description' => 'Contact us using our email form.'
		);

		// The form has been submitted?
		if (isset($_POST["email"]))
		{
			if ($_POST['abc'] == date("Y"))
			{
				$emailSender = new EmailSender(); // Instantiates a model
				$emailSender->send("antalkrisztian0@gmail.com", "Email from your website", $_POST['message'], $_POST['email']); // Calls the model
			}
		}

		// Sets the view
		$this->view = 'contact';
	}
}